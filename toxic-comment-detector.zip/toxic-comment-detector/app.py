"""Toxic Comment Detector - Streamlit app using a pre-trained multi-label model.

The .joblib file is a dict with:
  word_vec : TfidfVectorizer (word 1-2 grams)
  char_vec : TfidfVectorizer (char_wb 2-5 grams)
  models   : {label: LogisticRegression}
  labels   : list of label names
Features = hstack([word_vec, char_vec]) -> one binary classifier per label.
"""
import logging
import warnings
from pathlib import Path

import joblib
import scipy.sparse as sp
import streamlit as st

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("toxic-detector")

MODEL_PATH = Path(__file__).parent / "toxic_debiased.joblib"
THRESHOLD = 0.5  # same cut-off LogisticRegression.predict() uses
MAX_CHARS = 5000

META = {  # cosmetic only; the label list itself always comes from the model
    "toxic": ("☠️", "Toxic"),
    "severe_toxic": ("🚫", "Severe Toxic"),
    "obscene": ("🤬", "Obscene"),
    "threat": ("🚨", "Threat"),
    "insult": ("😡", "Insult"),
    "identity_hate": ("💔", "Identity Hate"),
}

st.set_page_config(page_title="Toxic Comment Detector", page_icon="✨", layout="wide")

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=Fraunces:opsz,wght@9..144,600;9..144,700&display=swap');
html, body, [class*="css"], .stMarkdown, .stTextArea textarea, .stButton button {font-family:'DM Sans',sans-serif;}
.stApp {background: linear-gradient(160deg,#fbf8ff 0%,#f4f9ff 45%,#fff7f3 100%);}
#MainMenu, footer {visibility:hidden;}
header[data-testid="stHeader"] {background:transparent;}
.block-container {padding-top:2rem; max-width:1150px;}
h1,h2,h3,.serif {font-family:'Fraunces',serif !important; color:#3f3556;}
[data-testid="stSidebar"] {background:linear-gradient(180deg,#efe7ff 0%,#e3f1ff 55%,#e2f8ef 100%); border-right:1px solid #e4dcf5;}
.side-title {font-family:'Fraunces',serif; font-size:1.35rem; font-weight:700; color:#3f3556; margin-bottom:.2rem;}
.side-sub {font-size:.8rem; color:#7a6f96; margin-bottom:1.2rem;}
.side-link {display:block; padding:.65rem .9rem; margin:.3rem 0; border-radius:14px; background:rgba(255,255,255,.65);
  color:#4b3f72 !important; text-decoration:none !important; font-weight:500; transition:all .15s;}
.side-link:hover {background:#fff; box-shadow:0 4px 14px rgba(120,100,180,.15); transform:translateX(2px);}
.side-foot {margin-top:2rem; padding:.8rem; border-radius:14px; background:rgba(255,255,255,.55); font-size:.78rem; color:#6b5f8a; text-align:center;}
.hero {background:linear-gradient(120deg,#ece3ff 0%,#ffe6f0 55%,#ffeede 100%); border-radius:28px; padding:2.4rem 2.2rem;
  box-shadow:0 10px 30px rgba(150,120,200,.15); margin-bottom:1.4rem;}
.hero h1 {font-size:2.7rem; margin:0 0 .4rem 0; line-height:1.1;}
.hero p {font-size:1.1rem; color:#5d5278; margin:0 0 1rem 0;}
.badge {display:inline-block; padding:.35rem .9rem; border-radius:999px; background:rgba(255,255,255,.8); color:#6b55a8;
  font-size:.82rem; font-weight:700; letter-spacing:.03em;}
.grid4 {display:grid; grid-template-columns:repeat(4,1fr); gap:1rem; margin-bottom:1.6rem;}
.grid3 {display:grid; grid-template-columns:repeat(3,1fr); gap:1rem; margin:.6rem 0 1.4rem 0;}
.gridcat {display:grid; grid-template-columns:repeat(auto-fill,minmax(190px,1fr)); gap:1rem; margin:1rem 0;}
@media (max-width:820px){.grid4{grid-template-columns:repeat(2,1fr);} .grid3{grid-template-columns:1fr;} .hero h1{font-size:2rem;}}
.card {border-radius:22px; padding:1.1rem 1.2rem; box-shadow:0 6px 20px rgba(120,100,170,.10); border:1px solid rgba(255,255,255,.7);}
.c-lav{background:#efe7ff;} .c-pink{background:#ffe3ee;} .c-blue{background:#e1f0ff;} .c-mint{background:#dff7ec;} .c-peach{background:#ffeadb;} .c-white{background:#fff;}
.card .lbl {font-size:.82rem; color:#6f6490; font-weight:500;}
.card .val {font-family:'Fraunces',serif; font-size:1.7rem; font-weight:700; color:#3f3556; margin:.15rem 0;}
.card .sub {font-size:.8rem; color:#7a6f96;}
.result {border-radius:24px; padding:1.5rem 1.7rem; margin:1rem 0; box-shadow:0 8px 24px rgba(120,100,170,.12);}
.result.safe {background:linear-gradient(120deg,#d9f6e8,#e6f9f1); border:1px solid #bfe9d4;}
.result.toxic {background:linear-gradient(120deg,#ffdce8,#ffe9e0); border:1px solid #f6c3d3;}
.result h3 {margin:0 0 .3rem 0; font-size:1.5rem;}
.result p {margin:0; color:#5d5278;}
.bar-row {margin:.75rem 0;}
.bar-head {display:flex; justify-content:space-between; font-weight:500; color:#4b3f72; margin-bottom:.25rem;}
.bar-bg {height:14px; border-radius:999px; background:#ece6f7; overflow:hidden;}
.bar-fill {height:100%; border-radius:999px;}
.f-hit {background:linear-gradient(90deg,#f7a8c4,#f9c0a8);} .f-ok {background:linear-gradient(90deg,#b8a6f0,#a9d0f5);}
.cat .name {font-weight:700; color:#3f3556;} .cat .pct {font-family:'Fraunces',serif; font-size:1.8rem; font-weight:700; color:#3f3556;}
.pill {display:inline-block; padding:.15rem .7rem; border-radius:999px; font-size:.75rem; font-weight:700; background:rgba(255,255,255,.8);}
.pill.hit {color:#b3416b;} .pill.ok {color:#2f8a64;}
.step .num {font-family:'Fraunces',serif; font-size:2rem; font-weight:700; color:#8a72cf;}
.step h4 {margin:.2rem 0; color:#3f3556;} .step p {margin:0; color:#5d5278; font-size:.92rem;}
.section-title {font-family:'Fraunces',serif; font-size:1.6rem; font-weight:700; color:#3f3556; margin:2rem 0 .3rem 0;}
.stTextArea textarea {border-radius:18px !important; border:2px solid #e0d6f5 !important; background:#fff !important; font-size:1rem; padding:1rem !important; color:#3f3556 !important;}
.stTextArea textarea:focus {border-color:#b39ddb !important; box-shadow:0 0 0 3px rgba(179,157,219,.25) !important;}
.stTextArea label p {font-weight:700; font-size:1.05rem; color:#3f3556;}
.stButton button {background:linear-gradient(90deg,#d9c9ff,#ffc9de); color:#4b3a7a; font-weight:700; font-size:1.05rem;
  border:none; border-radius:16px; padding:.7rem 2rem; box-shadow:0 6px 16px rgba(179,157,219,.35); transition:all .15s;}
.stButton button:hover {transform:translateY(-1px); box-shadow:0 10px 22px rgba(179,157,219,.45); color:#3a2a68; border:none;}
.about p, .about li {color:#5d5278; line-height:1.65;}
</style>
"""


def html(block: str) -> None:
    """Render HTML without markdown treating indented lines as code."""
    st.markdown("".join(line.strip() for line in block.splitlines()), unsafe_allow_html=True)


@st.cache_resource(show_spinner="Loading model…")
def load_model(path: str = str(MODEL_PATH)):
    """Load and validate the trained bundle. Returns (bundle, error_message)."""
    try:
        p = Path(path)
        if not p.exists():
            log.error("Model file not found: %s", p)
            return None, "The model file `toxic_debiased.joblib` was not found next to app.py."
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")  # sklearn version notice; versions are pinned in requirements.txt
            bundle = joblib.load(p)
        missing = {"word_vec", "char_vec", "models", "labels"} - set(bundle)
        if missing:
            log.error("Model bundle missing keys: %s", missing)
            return None, "The model file does not have the expected structure."
        return bundle, None
    except Exception:
        log.exception("Failed to load model")
        return None, "The model could not be loaded. Check that scikit-learn matches requirements.txt."


def predict(bundle, text: str) -> dict:
    """Return {label: probability} using the same features the model was trained on."""
    features = sp.hstack(
        [bundle["word_vec"].transform([text]), bundle["char_vec"].transform([text])]
    ).tocsr()
    return {lbl: float(bundle["models"][lbl].predict_proba(features)[0, 1]) for lbl in bundle["labels"]}


def pretty(label: str):
    return META.get(label, ("🏷️", label.replace("_", " ").title()))


def validate(text: str):
    text = (text or "").strip()
    if not text:
        return None, "Please enter a comment before analyzing."
    if not any(c.isalnum() for c in text):
        return None, "That input has no readable words. Please enter a real comment."
    if len(text) > MAX_CHARS:
        return None, f"Comments are limited to {MAX_CHARS:,} characters (yours has {len(text):,})."
    return text, None


def summary_cards(text=None, probs=None, total=6):
    if probs is None:
        vals = [("🔍 Comment Analysis", "—", "Waiting for input", "c-lav"),
                ("🛡️ Safety Status", "—", "Not analyzed yet", "c-mint"),
                ("📊 Toxicity Score", "—", "Highest category score", "c-blue"),
                ("🏷️ Categories Detected", "—", f"Out of {total} categories", "c-peach")]
    else:
        hits = [k for k, v in probs.items() if v >= THRESHOLD]
        top = max(probs.values())
        vals = [("🔍 Comment Analysis", f"{len(text.split())} words", f"{len(text)} characters", "c-lav"),
                ("🛡️ Safety Status", "Flagged" if hits else "Safe", "Review suggested" if hits else "No harmful content", "c-pink" if hits else "c-mint"),
                ("📊 Toxicity Score", f"{top:.0%}", "Highest category score", "c-blue"),
                ("🏷️ Categories Detected", f"{len(hits)} / {total}", ", ".join(pretty(h)[1] for h in hits) or "None", "c-peach")]
    cards = "".join(f'<div class="card {c}"><div class="lbl">{a}</div><div class="val">{b}</div><div class="sub">{s}</div></div>'
                    for a, b, s, c in vals)
    html(f'<div class="grid4">{cards}</div>')


def show_results(probs: dict):
    hits = [k for k, v in probs.items() if v >= THRESHOLD]
    if hits:
        html(f'<div class="result toxic"><h3>⚠️ Toxic content detected</h3>'
             f'<p>The model flagged {len(hits)} categor{"y" if len(hits) == 1 else "ies"}: '
             f'{", ".join(pretty(h)[1] for h in hits)}.</p></div>')
    else:
        html('<div class="result safe"><h3>🟢 Comment appears safe</h3>'
             '<p>🌸 <b>Looks good!</b> This comment does not appear to contain significant toxic content.</p></div>')

    st.markdown('<div class="section-title">📊 Toxicity probabilities</div>', unsafe_allow_html=True)
    bars = ""
    for lbl, p in sorted(probs.items(), key=lambda kv: -kv[1]):
        emoji, name = pretty(lbl)
        cls = "f-hit" if p >= THRESHOLD else "f-ok"
        bars += (f'<div class="bar-row"><div class="bar-head"><span>{emoji} {name}</span><span>{p:.0%}</span></div>'
                 f'<div class="bar-bg"><div class="bar-fill {cls}" style="width:{max(p * 100, 1):.1f}%"></div></div></div>')
    html(f'<div class="card c-white">{bars}</div>')

    st.markdown('<div class="section-title">🏷️ Category results</div>', unsafe_allow_html=True)
    cards = ""
    for lbl in probs:
        emoji, name = pretty(lbl)
        hit = probs[lbl] >= THRESHOLD
        cards += (f'<div class="card cat {"c-pink" if hit else "c-mint"}"><div class="name">{emoji} {name}</div>'
                  f'<div class="pct">{probs[lbl]:.0%}</div>'
                  f'<span class="pill {"hit" if hit else "ok"}">{"Detected" if hit else "Not detected"}</span></div>')
    html(f'<div class="gridcat">{cards}</div>')


# ----------------------------- page -----------------------------
st.markdown(CSS, unsafe_allow_html=True)

with st.sidebar:
    html('<div class="side-title">✨ Toxic Comment Detector</div><div class="side-sub">Understand harmful language</div>'
         '<a class="side-link" href="#home">🏠 Home</a><a class="side-link" href="#analyze">🔍 Analyze</a>'
         '<a class="side-link" href="#about">📖 About</a><a class="side-link" href="#how-it-works">ℹ️ How It Works</a>'
         '<div class="side-foot">Powered by NLP + Machine Learning</div>')

html('<div id="home"></div><div class="hero"><h1>✨ Toxic Comment Detector</h1>'
     '<p>AI-powered NLP system for detecting harmful and toxic online comments</p>'
     '<span class="badge">NLP • Machine Learning • Text Classification</span></div>')

bundle, load_error = load_model()
total_labels = len(bundle["labels"]) if bundle else 6
dashboard = st.empty()
with dashboard.container():
    summary_cards(total=total_labels)

html('<div id="analyze"></div>')
st.markdown('<div class="section-title">🔍 Analyze a comment</div>', unsafe_allow_html=True)

if load_error:
    st.error(f"😕 {load_error}")
else:
    comment = st.text_area("Enter a comment to analyze", height=170, placeholder="Type or paste a comment here...")
    if st.button("🔎 Analyze Comment"):
        text, problem = validate(comment)
        if problem:
            st.warning(f"✋ {problem}")
        else:
            try:
                with st.spinner("Analyzing…"):
                    probs = predict(bundle, text)
                with dashboard.container():
                    summary_cards(text, probs, total_labels)
                show_results(probs)
            except Exception:
                log.exception("Prediction failed")
                st.error("😕 Something went wrong while analyzing that comment. Please try a different one.")

html('<div id="about"></div>')
st.markdown('<div class="section-title">📖 About the Project</div>', unsafe_allow_html=True)
html('<div class="grid3 about">'
     '<div class="card c-lav"><h4>What is Toxic Comment Detection?</h4><p>It is a text classification task: reading a comment and deciding whether it contains harmful language such as insults, threats or hate.</p></div>'
     '<div class="card c-blue"><h4>How does it work?</h4><p>The text is turned into numerical word and character patterns (TF‑IDF). A trained machine-learning model then estimates how likely each type of toxicity is.</p></div>'
     '<div class="card c-peach"><h4>Why is it useful?</h4><p>Platforms and communities can use it to flag abusive comments early, helping moderators keep conversations safer and more respectful.</p></div></div>')

html('<div id="how-it-works"></div>')
st.markdown('<div class="section-title">ℹ️ How It Works</div>', unsafe_allow_html=True)
html('<div class="grid3">'
     '<div class="card step c-pink"><div class="num">01</div><h4>Enter Comment</h4><p>Type or paste any comment into the text box.</p></div>'
     '<div class="card step c-lav"><div class="num">02</div><h4>NLP Analysis</h4><p>The trained machine-learning model analyzes the text.</p></div>'
     '<div class="card step c-mint"><div class="num">03</div><h4>Get Results</h4><p>See toxicity categories and confidence scores instantly.</p></div></div>')
html('<p style="text-align:center;color:#8b80a8;font-size:.85rem;margin-top:2rem">Predictions are automated and can be wrong. Use them as guidance, not as a final judgment.</p>')
